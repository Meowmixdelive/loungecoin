# Lounge Coin Deployment Package

## Contents:
- scripts/ - All deployment scripts
- requirements.txt - Python dependencies
- production_requirements.txt - Production dependencies  
- .env.example - Environment variable template

## Quick Start:
1. Run: ./scripts/setup_server.sh (as root)
2. Upload your application code to /home/loungecoin/app
3. Run: ./scripts/deploy_app.sh (as loungecoin user)
4. Configure .env file
5. Run: ./scripts/setup_ssl.sh (as root)
