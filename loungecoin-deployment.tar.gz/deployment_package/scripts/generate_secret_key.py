#!/usr/bin/env python3
"""
Generate a secure SECRET_KEY for Django production
"""

import secrets
import string

def generate_secret_key(length=50):
    """Generate a secure random string for Django SECRET_KEY"""
    characters = string.ascii_letters + string.digits + string.punctuation
    # Remove problematic characters for shell/env files
    characters = characters.replace('"', '').replace("'", '').replace('\\', '')
    return ''.join(secrets.choice(characters) for _ in range(length))

if __name__ == '__main__':
    key = generate_secret_key()
    print("\nYour new SECRET_KEY:")
    print("-" * 60)
    print(key)
    print("-" * 60)
    print("\nAdd this to your .env file as:")
    print(f'SECRET_KEY={key}')
    print("\nKEEP THIS SECRET! Never commit it to version control.")