#!/bin/bash

# Lounge Coin Application Deployment Script
# Run as loungecoin user

set -e  # Exit on error

echo "=== Starting Lounge Coin Application Deployment ==="

cd /home/loungecoin/app

# Check if this is first deployment or update
if [ ! -d "venv" ]; then
    echo "First deployment detected. Setting up application..."
    FIRST_DEPLOY=true
else
    echo "Updating existing deployment..."
    FIRST_DEPLOY=false
fi

# Create virtual environment if it doesn't exist
if [ "$FIRST_DEPLOY" = true ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install/Update requirements
echo "Installing requirements..."
if [ -f "production_requirements.txt" ]; then
    pip install -r production_requirements.txt
else
    pip install -r requirements.txt
fi

# Install additional production packages
pip install gunicorn psycopg2-binary python-decouple whitenoise

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "Creating .env file..."
    cat > .env <<'ENV'
# Django Settings
SECRET_KEY=your-very-long-random-secret-key-change-this
DEBUG=False
ALLOWED_HOSTS=loungecoin.trade,www.loungecoin.trade

# Database - Update password!
DATABASE_URL=postgres://loungecoin:changethispassword@localhost/loungecoin_db

# Google OAuth - Add your credentials
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret

# Security
SECURE_SSL_REDIRECT=True
SESSION_COOKIE_SECURE=True
CSRF_COOKIE_SECURE=True
SECURE_HSTS_SECONDS=31536000
ENV
    echo "IMPORTANT: Edit .env file with your actual values!"
fi

# The production settings are already in place
echo "Production settings structure already configured..."

# Run migrations
echo "Running migrations..."
python manage.py migrate --settings=lounge_coin_project.settings.production

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --noinput --settings=lounge_coin_project.settings.production

# Create directories for logs and media
mkdir -p media/profile_pics
mkdir -p /home/loungecoin/logs

# Set permissions
chmod 755 /home/loungecoin/app
chmod 755 /home/loungecoin/app/media
chmod 755 /home/loungecoin/app/staticfiles

# Create Gunicorn configuration
echo "Creating Gunicorn configuration..."
cat > gunicorn_config.py <<'GUNICORN'
bind = "unix:/home/loungecoin/app/gunicorn.sock"
workers = 3
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
threads = 2
max_requests = 1000
max_requests_jitter = 50
preload_app = True
accesslog = "/home/loungecoin/logs/gunicorn_access.log"
errorlog = "/home/loungecoin/logs/gunicorn_error.log"
loglevel = "info"
GUNICORN

# Restart application
echo "Restarting application..."
sudo supervisorctl restart loungecoin

echo "=== Deployment Complete ==="
echo ""
echo "IMPORTANT REMINDERS:"
echo "1. Edit .env file with your actual values"
echo "2. Update PostgreSQL password"
echo "3. Add Google OAuth credentials"
echo "4. Create a superuser: python manage.py createsuperuser --settings=lounge_coin_project.settings.production"
echo "5. Run setup_ssl.sh to configure HTTPS"
echo ""
echo "Your application should now be running at http://loungecoin.trade"