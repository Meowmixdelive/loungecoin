"""
URL configuration for lounge_coin_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from coin_system import views

from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('', views.home, name='home'),
    path('users/', views.user_list, name='user_list'),
    path('transfer/', views.transfer_coins, name='transfer'),
    path('transactions/', views.transaction_history, name='transactions'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-gift/', views.admin_gift_coins, name='admin_gift'),
    path('logout-success/', views.custom_logout, name='logout_success'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('accounts/logout/', views.custom_logout_view, name='account_logout'),
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
