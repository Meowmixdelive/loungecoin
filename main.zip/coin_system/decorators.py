from functools import wraps
from django.core.exceptions import PermissionDenied


def admin_required(view_func):
    """
    Decorator for views that require admin privileges.
    """
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            from django.contrib.auth.decorators import login_required
            return login_required(view_func)(request, *args, **kwargs)
        
        if not request.user.is_admin:
            raise PermissionDenied("Admin privileges required.")
        
        return view_func(request, *args, **kwargs)
    return wrapper