from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Transaction


class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'coin_balance', 'is_admin', 'is_staff')
    list_filter = ('is_admin', 'is_staff', 'is_superuser')
    
    fieldsets = UserAdmin.fieldsets + (
        ('Lounge Coin Info', {'fields': ('coin_balance', 'is_admin')}),
    )
    
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Lounge Coin Info', {'fields': ('coin_balance', 'is_admin')}),
    )


class TransactionAdmin(admin.ModelAdmin):
    list_display = ('sender', 'receiver', 'amount', 'timestamp')
    list_filter = ('timestamp',)
    search_fields = ('sender__username', 'receiver__username')
    readonly_fields = ('timestamp',)
    

admin.site.register(User, CustomUserAdmin)
admin.site.register(Transaction, TransactionAdmin)