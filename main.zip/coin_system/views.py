from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib import messages
from django.db import transaction, models
from django.core.exceptions import PermissionDenied
from decimal import Decimal
from .models import User, Transaction
from .forms import TransferForm, AdminGiftForm, ProfileForm
from .decorators import admin_required


def home(request):
    return render(request, 'home.html')


@login_required
def user_list(request):
    users = User.objects.all().order_by('-coin_balance')
    return render(request, 'user_list.html', {'users': users})


@login_required
def transfer_coins(request):
    form = TransferForm(request.user)
    
    if request.method == 'POST':
        form = TransferForm(request.user, request.POST)
        if form.is_valid():
            receiver = form.cleaned_data['receiver']
            amount = form.cleaned_data['amount']
            notes = form.cleaned_data['notes']
            
            try:
                with transaction.atomic():
                    # Lock the user records to prevent race conditions
                    sender = User.objects.select_for_update().get(id=request.user.id)
                    receiver = User.objects.select_for_update().get(id=receiver.id)
                    
                    # Double-check balance after lock
                    if amount > sender.coin_balance:
                        messages.error(request, "Insufficient balance.")
                        return render(request, 'transfer.html', {'form': form})
                    
                    sender.coin_balance -= amount
                    sender.save()
                    
                    receiver.coin_balance += amount
                    receiver.save()
                    
                    Transaction.objects.create(
                        sender=sender,
                        receiver=receiver,
                        amount=amount,
                        notes=notes or ''
                    )
                    
                messages.success(request, f"Successfully transferred {amount} coins to {receiver.username}.")
                return redirect('transfer')
                
            except Exception as e:
                messages.error(request, "Transfer failed. Please try again.")
    
    return render(request, 'transfer.html', {'form': form})


@login_required
def transaction_history(request):
    sent_transactions = Transaction.objects.filter(sender=request.user)
    received_transactions = Transaction.objects.filter(receiver=request.user)
    
    all_transactions = list(sent_transactions) + list(received_transactions)
    all_transactions.sort(key=lambda x: x.timestamp, reverse=True)
    
    return render(request, 'transactions.html', {'transactions': all_transactions})


@admin_required
def admin_gift_coins(request):
    
    form = AdminGiftForm()
    
    if request.method == 'POST':
        form = AdminGiftForm(request.POST)
        if form.is_valid():
            receiver = form.cleaned_data['receiver']
            amount = form.cleaned_data['amount']
            notes = form.cleaned_data['notes']
            
            try:
                with transaction.atomic():
                    receiver = User.objects.select_for_update().get(id=receiver.id)
                    receiver.coin_balance += amount
                    receiver.save()
                    
                    Transaction.objects.create(
                        sender=request.user,
                        receiver=receiver,
                        amount=amount,
                        notes=f"Admin gift: {notes}" if notes else "Admin gift"
                    )
                    
                messages.success(request, f"Successfully gifted {amount} coins to {receiver.username}.")
                return redirect('admin_gift')
                
            except Exception as e:
                messages.error(request, "Gift failed. Please try again.")
    
    return render(request, 'admin_gift.html', {'form': form})


@admin_required
def admin_dashboard(request):
    
    total_users = User.objects.count()
    total_coins = User.objects.aggregate(total=models.Sum('coin_balance'))['total'] or 0
    recent_transactions = Transaction.objects.all()[:10]
    
    context = {
        'total_users': total_users,
        'total_coins': total_coins,
        'recent_transactions': recent_transactions,
    }
    
    return render(request, 'admin_dashboard.html', context)


def custom_logout(request):
    """Custom logout success page"""
    return render(request, 'account/logout.html')


def custom_logout_view(request):
    """Custom logout view that handles the actual logout process"""
    if request.method == 'POST':
        # User confirmed logout
        logout(request)
        return redirect('logout_success')
    else:
        # Show logout confirmation
        if request.user.is_authenticated:
            return render(request, 'account/logout_confirm.html')
        else:
            # Already logged out, show success page
            return redirect('logout_success')


@login_required
def edit_profile(request):
    """Edit user profile"""
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('edit_profile')
    else:
        form = ProfileForm(instance=request.user)
    
    return render(request, 'profile/edit.html', {'form': form})
