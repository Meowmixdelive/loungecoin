#!/bin/bash

# SSL Certificate Setup Script for loungecoin.trade
# Run as root or with sudo

set -e  # Exit on error

echo "=== Setting up SSL Certificate for loungecoin.trade ==="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root or with sudo"
    exit 1
fi

# Check if domain is resolving
echo "Checking domain resolution..."
if ! host loungecoin.trade > /dev/null 2>&1; then
    echo "ERROR: loungecoin.trade is not resolving to an IP address"
    echo "Please ensure DNS is properly configured and propagated"
    exit 1
fi

# Get the server's IP
SERVER_IP=$(curl -s http://checkip.amazonaws.com)
DOMAIN_IP=$(dig +short loungecoin.trade | head -1)

echo "Server IP: $SERVER_IP"
echo "Domain IP: $DOMAIN_IP"

if [ "$SERVER_IP" != "$DOMAIN_IP" ]; then
    echo "WARNING: Domain IP doesn't match server IP"
    echo "DNS may not be fully propagated yet"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Install certbot if not already installed
if ! command -v certbot &> /dev/null; then
    echo "Installing certbot..."
    snap install --classic certbot
    ln -s /snap/bin/certbot /usr/bin/certbot
fi

# Stop nginx temporarily to avoid conflicts
echo "Configuring SSL certificate..."
systemctl stop nginx

# Obtain certificate
certbot certonly --standalone \
    -d loungecoin.trade \
    -d www.loungecoin.trade \
    --non-interactive \
    --agree-tos \
    --email admin@loungecoin.trade \
    --redirect \
    --keep-until-expiring

# Update Nginx configuration for SSL
echo "Updating Nginx configuration..."
cat > /etc/nginx/sites-available/loungecoin <<'NGINX'
# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name loungecoin.trade www.loungecoin.trade;
    return 301 https://$server_name$request_uri;
}

# Main HTTPS server
server {
    listen 443 ssl;
    server_name loungecoin.trade www.loungecoin.trade;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/loungecoin.trade/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/loungecoin.trade/privkey.pem;
    
    # Strong SSL Security
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK;
    ssl_prefer_server_ciphers on;
    
    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    
    # Other security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # Locations
    location = /favicon.ico { access_log off; log_not_found off; }
    
    location /static/ {
        alias /home/loungecoin/app/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    location /media/ {
        alias /home/loungecoin/app/media/;
        expires 7d;
        add_header Cache-Control "public, must-revalidate";
    }
    
    location / {
        include proxy_params;
        proxy_pass http://unix:/home/loungecoin/app/gunicorn.sock;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    client_max_body_size 10M;
}
NGINX

# Test Nginx configuration
nginx -t

# Start Nginx
systemctl start nginx
systemctl reload nginx

# Set up automatic renewal
echo "Setting up automatic certificate renewal..."
cat > /etc/systemd/system/certbot-renewal.service <<'SERVICE'
[Unit]
Description=Certbot Renewal
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/bin/certbot renew --quiet --deploy-hook "systemctl reload nginx"
SERVICE

cat > /etc/systemd/system/certbot-renewal.timer <<'TIMER'
[Unit]
Description=Run certbot renewal twice daily

[Timer]
OnCalendar=*-*-* 00,12:00:00
RandomizedDelaySec=3600
Persistent=true

[Install]
WantedBy=timers.target
TIMER

# Enable the timer
systemctl daemon-reload
systemctl enable certbot-renewal.timer
systemctl start certbot-renewal.timer

echo "=== SSL Setup Complete ==="
echo ""
echo "Your site is now available at:"
echo "  https://loungecoin.trade"
echo "  https://www.loungecoin.trade"
echo ""
echo "Certificate will auto-renew before expiration"
echo ""
echo "To test SSL configuration:"
echo "  Visit: https://www.ssllabs.com/ssltest/analyze.html?d=loungecoin.trade"