#!/bin/bash

# Quick update script for Lounge Coin
# Run as loungecoin user when you push new code

set -e

echo "=== Updating Lounge Coin Application ==="

cd /home/loungecoin/app

# Activate virtual environment
source venv/bin/activate

# Pull latest changes (assuming you're using git)
echo "Pulling latest changes..."
git pull origin main

# Install any new requirements
echo "Updating requirements..."
pip install -r requirements.txt

# Run migrations
echo "Running migrations..."
python manage.py migrate --settings=lounge_coin_project.settings_production

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --noinput --settings=lounge_coin_project.settings_production

# Restart application
echo "Restarting application..."
sudo supervisorctl restart loungecoin

echo "=== Update Complete ==="
echo "Check your site at https://loungecoin.trade"